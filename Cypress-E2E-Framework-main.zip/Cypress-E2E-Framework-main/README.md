# Cypress-E2E-Framework

Cypress test automation framework built against the OpenCart demo store, using the Page Object Model. See [PROJECT_DESCRIPTION.md](./PROJECT_DESCRIPTION.md) for the why/approach behind it.

## Structure

```
cypress/
  e2e/tests/        test specs (addToCartTest.cy.js, registerTest.cy.js)
  pages/             page objects (homePage.cy.js, registerPage.cy.js)
  fixtures/          test data (testData.json, registerData.json)
  support/
    commands.js      custom commands (cy.login)
    e2e.js           global config, loads commands + mochawesome reporter
  reports/html/      generated HTML reports (mochawesome)
cypress.config.js     Cypress config, base URL, reporter setup
```

## Setup

```
npm install
```

## Running tests

```
npm run test:addToCart      # add to cart flow
npm run test:registerFlow   # registration flow
npm run test:browser        # add to cart flow on Chrome
npm run cy:parallel         # run specs in parallel (cypress-parallel)
```

Or open the Cypress UI directly:

```
npx cypress open
```

## Test data

Login credentials, product name, and expected messages live in `cypress/fixtures/testData.json`. Registration form data lives in `cypress/fixtures/registerData.json`. Update these instead of hardcoding values in the specs.

## CI

GitHub Actions runs on every push, covering a standard run, Chrome-only, Firefox, a sanity/smoke run, and a parallel run that splits the two flows into separate jobs. See `.github/workflows/`.

## Reports

Test runs generate an HTML report via `cypress-mochawesome-reporter` under `cypress/reports/html/`.
.
