# Project Description

**Cypress E2E Framework — OpenCart Test Automation Practice**

A Cypress test automation framework built against the OpenCart demo store (naveenautomationlabs.com) to practice the Page Object Model, custom commands, data-driven tests, and CI integration across browsers and in parallel.

## Problem

I wanted a framework to practice core Cypress patterns beyond one-off scripts: separating locators and actions from test logic, reusable login/setup steps, pulling test data from fixtures instead of hardcoding it, and getting the whole thing running in CI.

## Approach

- **Page Object Model** — `cypress/pages/` holds page classes (`homePage`, `registerPage`) with locators and actions; `cypress/e2e/tests/` holds the specs that call into them.
- **Custom commands** — a `cy.login()` command in `cypress/support/commands.js` handles the shared login flow so individual tests don't repeat it.
- **Fixtures** — login credentials, product name, expected messages, and registration details all come from JSON fixtures (`cypress/fixtures/`) rather than being hardcoded in specs.
- **Reporting** — `cypress-mochawesome-reporter` generates HTML test reports for each run.
- **CI** — five GitHub Actions workflows: a standard run, a Chrome-only run, a Firefox run, a sanity/smoke run, and a parallelized run (via `cypress-parallel`) that splits the add-to-cart and registration flows into separate jobs and uploads each one's report as a build artifact.

## Tech Stack

Cypress, cypress-parallel, cypress-mochawesome-reporter, GitHub Actions.

## Status

Personal practice project against a public demo site (OpenCart on naveenautomationlabs.com) — not testing a real product.
